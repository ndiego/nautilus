<?php
/**
 * Title: Query no results
 * Slug: nautilus/hidden-query-no-results
 * Inserter: no
 */

?>
<!-- wp:query-no-results -->
	<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"3rem","bottom":"3rem","left":"3rem"}},"border":{"radius":"8px","width":"1px","color":"#d4d4d8"}},"backgroundColor":"white"} -->
	<div class="wp-block-group has-border-color has-white-background-color has-background" style="border-color:#d4d4d8;border-width:1px;border-radius:8px;padding-top:3rem;padding-right:3rem;padding-bottom:3rem;padding-left:3rem"><!-- wp:paragraph {"align":"center"} -->
	<p class="has-text-align-center">No posts could be found.</p>
	<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
<!-- /wp:query-no-results -->